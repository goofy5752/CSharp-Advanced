﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Food
{
    public class Meat : Food
    {

    }
}