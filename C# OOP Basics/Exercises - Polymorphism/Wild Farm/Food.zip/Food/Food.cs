﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Food
{
    public abstract class Food
    {
        public Food()
        {

        }

        public int Quantity { get; set; }
    }
}