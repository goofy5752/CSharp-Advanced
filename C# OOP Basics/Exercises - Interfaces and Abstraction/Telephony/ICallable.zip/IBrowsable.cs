﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TelephonyProj
{
    public interface IBrowsable
    {
        string SiteName { get; }
    }
}