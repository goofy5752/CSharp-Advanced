﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TelephonyProj
{
    public interface ICallable
    {
        string NumberId { get; }
    }
}