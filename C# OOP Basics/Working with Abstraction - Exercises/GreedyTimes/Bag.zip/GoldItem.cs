﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GreedyTimes
{
    public class GoldItem : Item
    {
        public GoldItem(string key, long value)
        {
            Key = key;
            Value = value;
        }
    }
}
