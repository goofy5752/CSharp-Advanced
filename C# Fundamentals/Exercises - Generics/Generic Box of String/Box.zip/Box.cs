﻿namespace Generic_Box_of_String
{
    public class Box<T>
    {
        public T Result { get; set; }

        public Box(T value)
        {
            this.Result = value;
        }

        public override string ToString()
        {
            return $"{typeof(T)}: {Result}" + Environment.NewLine;
        }
    }
}
