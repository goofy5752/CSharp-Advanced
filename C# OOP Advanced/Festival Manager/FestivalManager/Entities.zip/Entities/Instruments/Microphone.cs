﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FestivalManager.Entities.Instruments
{
    public class Microphone : Instrument
    {
        public Microphone()
        {
            this.RepairAmount = 80;
        }
    }
}