﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FestivalManager.Entities.Instruments
{
    public class Drums : Instrument
    {
        public Drums()
        {
            this.RepairAmount = 20;
        }
    }
}
